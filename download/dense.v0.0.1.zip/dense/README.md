Dense
=====

[Issues](https://github.com/gocom/dense/issues) | [![Build Status](https://travis-ci.org/gocom/dense.png?branch=master)](https://travis-ci.org/gocom/dense)